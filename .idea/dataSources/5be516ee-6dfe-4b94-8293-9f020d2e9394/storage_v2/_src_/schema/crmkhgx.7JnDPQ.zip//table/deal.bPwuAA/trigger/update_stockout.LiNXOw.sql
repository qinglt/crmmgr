create definer = root@localhost trigger update_stockOut
    after insert
    on deal
    for each row
BEGIN
UPDATE stock set stockOut = stockOut + new.dealNumber WHERE stockId = new.dealStock;
END;

