create definer = root@localhost trigger update_stockLeft
    after insert
    on deal
    for each row
BEGIN
UPDATE stock set stockLeft = stockLeft - new.dealNumber where stockId = new.dealStock;
END;

